//
//  CollectionCell.swift
//  PageViewSample
//
//  Created by rakeshkumar thammishetty on 11/05/19.
//  Copyright © 2019 Altair. All rights reserved.
//

import UIKit

class CollectionCell: UICollectionViewCell {
    @IBOutlet weak var cellImg: UIImageView!
    
    @IBOutlet weak var cellLbl: UILabel!
}
