//
//  ViewController.swift
//  PageViewSample
//
//  Created by rakeshkumar thammishetty on 11/05/19.
//  Copyright © 2019 Altair. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource {

    @IBOutlet weak var pageController: UIPageControl!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var scrollView: UIScrollView!
        {
        didSet{
            scrollView.delegate = self
        }
    }
    
    let imageNames = ["1.jpg","2.jpg","3.jpg","4.jpg","5.jpg","6.jpg","7.jpg"]

    override func viewDidLoad() {
        super.viewDidLoad()
        var imgArray = [UIImage]()
        collectionView.delegate = self
        collectionView.dataSource = self
        pageController.numberOfPages = self.imageNames.count
        pageController.currentPage = 0
        view.bringSubviewToFront(pageController)

        
        for i in 0..<imageNames.count {
            let img: UIImage = UIImage.init(named: imageNames[i])!
                imgArray.append(img)
        }
        for i in 0..<imgArray.count {
            let imageView = UIImageView()
            imageView.image = imgArray[i]
            let xPosition = self.view.frame.width * CGFloat(i)
            imageView.frame = CGRect(x: xPosition, y: 0, width:
                self.scrollView.frame.width + 50, height: self.scrollView.frame.height)
            self.scrollView.contentSize.width = self.scrollView.frame.width * CGFloat(i + 1)
            self.scrollView.addSubview(imageView)
            
        }
        
        //self.scrollView.delegate = self
        
            func scrollView(_ scrollView: UIScrollView, didScrollToPercentageOffset percentageHorizontalOffset: CGFloat) {
            if(pageController.currentPage == 0) {
                //Change background color to toRed: 103/255, fromGreen: 58/255, fromBlue: 183/255, fromAlpha: 1
                //Change pageControl selected color to toRed: 103/255, toGreen: 58/255, toBlue: 183/255, fromAlpha: 0.2
                //Change pageControl unselected color to toRed: 255/255, toGreen: 255/255, toBlue: 255/255, fromAlpha: 1
                
                let pageUnselectedColor: UIColor = fade(fromRed: 255/255, fromGreen: 255/255, fromBlue: 255/255, fromAlpha: 1, toRed: 103/255, toGreen: 58/255, toBlue: 183/255, toAlpha: 1, withPercentage: percentageHorizontalOffset * 3)
                pageController.pageIndicatorTintColor = pageUnselectedColor
                
                
                let bgColor: UIColor = fade(fromRed: 103/255, fromGreen: 58/255, fromBlue: 183/255, fromAlpha: 1, toRed: 255/255, toGreen: 255/255, toBlue: 255/255, toAlpha: 1, withPercentage: percentageHorizontalOffset * 3)
//scrollView[pageController.currentPage].backgroundColor = bgColor
                
                let pageSelectedColor: UIColor = fade(fromRed: 81/255, fromGreen: 36/255, fromBlue: 152/255, fromAlpha: 1, toRed: 103/255, toGreen: 58/255, toBlue: 183/255, toAlpha: 1, withPercentage: percentageHorizontalOffset * 3)
                pageController.currentPageIndicatorTintColor = pageSelectedColor
            }
        }
        
        
    }
    func fade(fromRed: CGFloat,
              fromGreen: CGFloat,
              fromBlue: CGFloat,
              fromAlpha: CGFloat,
              toRed: CGFloat,
              toGreen: CGFloat,
              toBlue: CGFloat,
              toAlpha: CGFloat,
              withPercentage percentage: CGFloat) -> UIColor {
        
        let red: CGFloat = (toRed - fromRed) * percentage + fromRed
        let green: CGFloat = (toGreen - fromGreen) * percentage + fromGreen
        let blue: CGFloat = (toBlue - fromBlue) * percentage + fromBlue
        let alpha: CGFloat = (toAlpha - fromAlpha) * percentage + fromAlpha
        
        // return the fade colour
        return UIColor(red: red, green: green, blue: blue, alpha: alpha)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return imageNames.count
    }
    
     func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionCell
        let image = UIImage(named: imageNames[indexPath.row])
            cell.cellImg.image = image
    
        return cell
    }
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
////        let modelName = UIDevice.modelName
////        if modelName == "Simulator iPhone 5s" || modelName == "Simulator iPhone 6s" || modelName == "iPhone 6" || modelName == "iPhone 6s" || modelName == "iPhone 5s" || modelName == "Simulator iPhone X"
////        {
////            return CGSize(width: 90 , height: 120)
////        }
////        else{
//            return CGSize(width: 120 , height: 120)
//      //  }
//    }
    


}

